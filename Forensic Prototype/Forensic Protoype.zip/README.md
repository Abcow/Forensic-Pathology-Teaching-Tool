Hello! Thanks for reading this just a few words from the developers...

This is a prototype, nothing is finialised and many features are missing and have been removed as they are in a rather incomplete/buggy state.The styling (colours & look of the site) has also yet to be finialised, for this reason it has been left simple & rather horrible.

Features to show off...
0. to get started open the index.html file in your webbrowser (reccomended GooogleChrome, as that is what we used for testing) To view other pages use the navigation bar buttons -> Home leads to the first page (index) & the left & right buttons go left & right.
+ & - are currently unimplemented & will likely be hidden on everything but the interactive screens.

1. The Navigation bar at the bottom of the screen, hover your mouse towards the bottom to see the navigation bar & buttons. Please feel free to feedback on the design of the buttons & the style of the navigation bar.

2. The text is example placer text, as we are not medical students we have no idea what should be there. We are currenty writing a system using something called "AJAX" which will get text & other resources from different files, in a more customisable format

3. On the interactive page there flowing menus from the right & left, similar to the navigation menus. These buttons are currenltly placeholder, but will show different views of the scences in the interactive parts of the website.

4. Click on a part of the body to read an explination about the clicked part. Currently I screwed up and the whole body is the click area... I'll fix that later :D

5. The quiz is currently shows a message if the correct answer is pressed. A way to handle incorrect messages will be added later :)

6. Thanks for reading! :D